<?php
/**
 * Plugin Name: RLC Membership Core
 * Description: Sistema integral de membresías para Red LATAM COIL con API REST para React, integración con WooCommerce y Panel Administrativo.
 * Version: 2.0.0
 * Author: Gemini AI & Hazlo Mejor
 */

if (!defined('ABSPATH')) exit;

class RLC_Membership_Core {

    public function __construct() {
        // 1. Inicialización y API
        add_action('rest_api_init', [$this, 'register_routes']);
        add_action('init', [$this, 'register_user_meta_fields']);

        // 2. Integración WooCommerce
        add_action('woocommerce_order_status_completed', [$this, 'handle_membership_purchase']);
        add_action('woocommerce_checkout_update_order_meta', [$this, 'save_checkout_fields_to_order']);

        // 3. Automatización (Cron Job)
        add_action('rlc_daily_expiry_check', [$this, 'check_expirations']);
        if (!wp_next_scheduled('rlc_daily_expiry_check')) {
            wp_schedule_event(time(), 'daily', 'rlc_daily_expiry_check');
        }

        // 4. Panel Administrativo
        add_action('admin_menu', [$this, 'add_admin_menu']);
        
        // 5. CORS para React
        add_action('rest_api_init', [$this, 'handle_cors'], 15);
    }

    /**
     * REGISTRO DE RUTAS API REST
     */
    public function register_routes() {
        register_rest_route('rlc/v1', '/user/profile', [
            'methods'  => 'GET',
            'callback' => [$this, 'get_user_profile'],
            'permission_callback' => [$this, 'is_authenticated']
        ]);

        register_rest_route('rlc/v1', '/user/status', [
            'methods'  => 'GET',
            'callback' => [$this, 'get_user_status'],
            'permission_callback' => [$this, 'is_authenticated']
        ]);
    }

    public function is_authenticated() {
        return is_user_logged_in();
    }

    public function handle_cors() {
        remove_filter('rest_pre_serve_request', 'rest_send_cors_headers');
        add_filter('rest_pre_serve_request', function($value) {
            header('Access-Control-Allow-Origin: *'); 
            header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
            header('Access-Control-Allow-Credentials: true');
            header('Access-Control-Allow-Headers: Authorization, Content-Type, X-WP-Nonce');
            return $value;
        });
    }

    /**
     * CALLBACKS DE LA API
     */
    public function get_user_profile() {
        $user_id = get_current_user_id();
        $user = get_userdata($user_id);

        return new WP_REST_Response([
            'id'           => $user_id,
            'full_name'    => $user->display_name,
            'email'        => $user->user_email,
            'university'   => get_user_meta($user_id, 'rlc_university', true) ?: '',
            'country'      => get_user_meta($user_id, 'rlc_country', true) ?: '',
            'position'     => get_user_meta($user_id, 'rlc_position', true) ?: '',
            'linkedin'     => get_user_meta($user_id, 'rlc_linkedin', true) ?: '',
            'membership'   => get_user_meta($user_id, 'rlc_membership_level', true) ?: 'Ninguna',
            'status'       => get_user_meta($user_id, 'rlc_status', true) ?: 'inactive',
            'expiry_date'  => get_user_meta($user_id, 'rlc_expiry_date', true) ?: 'N/A',
            'avatar'       => get_avatar_url($user_id),
        ], 200);
    }

    public function get_user_status() {
        $user_id = get_current_user_id();
        return new WP_REST_Response([
            'status' => get_user_meta($user_id, 'rlc_status', true) ?: 'pending',
            'level'  => get_user_meta($user_id, 'rlc_membership_level', true) ?: 'none'
        ], 200);
    }

    /**
     * LÓGICA DE WOOCOMMERCE
     */
    public function save_checkout_fields_to_order($order_id) {
        $fields = ['rlc_university', 'rlc_country', 'rlc_position', 'rlc_linkedin'];
        foreach ($fields as $field) {
            if (!empty($_POST[$field])) {
                update_post_meta($order_id, '_' . $field, sanitize_text_field($_POST[$field]));
            }
        }
    }

    public function handle_membership_purchase($order_id) {
        $order = wc_get_order($order_id);
        $user_id = $order->get_user_id();
        if (!$user_id) return;

        foreach ($order->get_items() as $item) {
            $name = strtolower($item->get_name());
            $level = '';

            if (strpos($name, 'oro') !== false || strpos($name, 'institucional') !== false) $level = 'Oro';
            elseif (strpos($name, 'plata') !== false || strpos($name, 'profesional') !== false) $level = 'Plata';
            elseif (strpos($name, 'bronce') !== false || strpos($name, 'estudiante') !== false) $level = 'Bronce';

            if ($level) {
                update_user_meta($user_id, 'rlc_membership_level', $level);
                update_user_meta($user_id, 'rlc_status', 'active');
                update_user_meta($user_id, 'rlc_expiry_date', date('Y-m-d', strtotime('+1 year')));
                
                // Pasar datos del pedido al perfil del usuario
                $meta_map = ['rlc_university', 'rlc_country', 'rlc_position', 'rlc_linkedin'];
                foreach ($meta_map as $m) {
                    $val = $order->get_meta('_' . $m);
                    if ($val) update_user_meta($user_id, $m, $val);
                }
            }
        }
    }

    /**
     * AUTOMATIZACIÓN DE VENCIMIENTOS
     */
    public function check_expirations() {
        $users = get_users([
            'meta_query' => [
                'relation' => 'AND',
                ['key' => 'rlc_expiry_date', 'value' => date('Y-m-d'), 'compare' => '<=', 'type' => 'DATE'],
                ['key' => 'rlc_status', 'value' => 'active', 'compare' => '=']
            ]
        ]);
        foreach ($users as $u) {
            update_user_meta($u->ID, 'rlc_status', 'expired');
        }
    }

    public function register_user_meta_fields() {
        $meta = ['rlc_university', 'rlc_country', 'rlc_position', 'rlc_linkedin', 'rlc_membership_level', 'rlc_status', 'rlc_expiry_date'];
        foreach ($meta as $f) {
            register_meta('user', $f, ['type' => 'string', 'single' => true, 'show_in_rest' => true]);
        }
    }

    /**
     * PANEL ADMINISTRATIVO (GESTIÓN MANUAL)
     */
    public function add_admin_menu() {
        add_menu_page('RLC Membresías', 'RLC Membresías', 'manage_options', 'rlc-admin', [$this, 'admin_page_html'], 'dashicons-groups', 6);
    }

    public function admin_page_html() {
        // Procesar Formulario Manual
        if (isset($_POST['rlc_save_manual']) && check_admin_referer('rlc_manual_action')) {
            $u_id = intval($_POST['user_id']);
            update_user_meta($u_id, 'rlc_membership_level', sanitize_text_field($_POST['level']));
            update_user_meta($u_id, 'rlc_status', sanitize_text_field($_POST['status']));
            update_user_meta($u_id, 'rlc_expiry_date', sanitize_text_field($_POST['expiry']));
            echo '<div class="updated"><p>Usuario actualizado correctamente.</p></div>';
        }

        $members = get_users(['meta_query' => [['key' => 'rlc_status', 'compare' => 'EXISTS']]]);
        $all_users = get_users(['fields' => ['ID', 'display_name', 'user_email']]);
        ?>
        <div class="wrap">
            <h1 style="color: #1D3E51;">Gestión de Membresías RLC</h1>
            
            <div style="display: flex; gap: 20px;">
                <div style="flex: 2;">
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th>Usuario</th>
                                <th>Nivel</th>
                                <th>Estado</th>
                                <th>Vencimiento</th>
                                <th>Acción</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($members as $m): ?>
                            <tr>
                                <td><strong><?php echo $m->display_name; ?></strong></td>
                                <td><?php echo get_user_meta($m->ID, 'rlc_membership_level', true); ?></td>
                                <td><?php echo strtoupper(get_user_meta($m->ID, 'rlc_status', true)); ?></td>
                                <td><?php echo get_user_meta($m->ID, 'rlc_expiry_date', true); ?></td>
                                <td><button class="button" onclick="loadUser('<?php echo $m->ID; ?>', '<?php echo get_user_meta($m->ID, 'rlc_membership_level', true); ?>', '<?php echo get_user_meta($m->ID, 'rlc_status', true); ?>', '<?php echo get_user_meta($m->ID, 'rlc_expiry_date', true); ?>')">Editar</button></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div style="flex: 1; background: #fff; padding: 20px; border: 1px solid #ccc;">
                    <h3>Asignación / Edición Manual</h3>
                    <form method="post">
                        <?php wp_nonce_field('rlc_manual_action'); ?>
                        <label>Usuario:</label>
                        <select name="user_id" id="f_user" style="width:100%" required>
                            <?php foreach($all_users as $au): ?>
                                <option value="<?php echo $au->ID; ?>"><?php echo $au->display_name; ?></option>
                            <?php endforeach; ?>
                        </select><br><br>
                        <label>Nivel:</label>
                        <select name="level" id="f_level" style="width:100%">
                            <option value="Oro">Oro</option>
                            <option value="Plata">Plata</option>
                            <option value="Bronce">Bronce</option>
                        </select><br><br>
                        <label>Estado:</label>
                        <select name="status" id="f_status" style="width:100%">
                            <option value="active">Activo</option>
                            <option value="expired">Vencido</option>
                            <option value="pending">Pendiente</option>
                        </select><br><br>
                        <label>Vencimiento:</label>
                        <input type="date" name="expiry" id="f_expiry" style="width:100%" required><br><br>
                        <input type="submit" name="rlc_save_manual" class="button button-primary" value="Guardar Cambios">
                    </form>
                </div>
            </div>
        </div>
        <script>
            function loadUser(id, level, status, expiry) {
                document.getElementById('f_user').value = id;
                document.getElementById('f_level').value = level;
                document.getElementById('f_status').value = status;
                document.getElementById('f_expiry').value = expiry;
            }
        </script>
        <?php
    }
}

new RLC_Membership_Core();

// Limpieza al desactivar
register_deactivation_hook(__FILE__, function() {
    wp_clear_scheduled_hook('rlc_daily_expiry_check');
});